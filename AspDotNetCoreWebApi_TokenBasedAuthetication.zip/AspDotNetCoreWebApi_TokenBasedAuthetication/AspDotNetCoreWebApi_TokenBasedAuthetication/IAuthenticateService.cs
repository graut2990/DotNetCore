﻿using AspDotNetCoreWebApi_TokenBasedAuthetication.Model;
using Microsoft.Extensions.Options;
using Microsoft.IdentityModel.Tokens;
using System;
using System.Collections.Generic;
using System.IdentityModel.Tokens.Jwt;
using System.Linq;
using System.Security.Claims;
using System.Text;
using System.Threading.Tasks;

namespace AspDotNetCoreWebApi_TokenBasedAuthetication
{
    public interface IAuthenticateService
    {
        bool IsAuthenticated(UserModel request, out string token);
    }

    public class TokenAuthenticationService : IAuthenticateService
    {
        private readonly TokenManagement _tokenManagement;

        public TokenAuthenticationService(IOptions<TokenManagement> tokenManagement)
        {
            _tokenManagement = tokenManagement.Value;
        }
        public bool IsAuthenticated(UserModel request, out string token)
        {
            token = string.Empty;
            var securityKey = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(_tokenManagement.Secret));
            var credentials = new SigningCredentials(securityKey, SecurityAlgorithms.HmacSha256);

            List<Claim> claims = new List<Claim>();
            claims.Add(new Claim(JwtRegisteredClaimNames.GivenName, request.Username));
            claims.Add(new Claim("Role", request.Role));
            claims.Add(new Claim("access", "report"));
            claims.Add(new Claim(ClaimTypes.Name, "alice", ClaimValueTypes.String));
            claims.Add(new Claim(JwtRegisteredClaimNames.Email, request.EmailAddress));

            var jwtToken = new JwtSecurityToken(
              _tokenManagement.Issuer,
              _tokenManagement.Audience,
              claims,
              expires: DateTime.Now.AddMinutes(_tokenManagement.AccessExpiration),
              signingCredentials: credentials
          );

            token = new JwtSecurityTokenHandler().WriteToken(jwtToken);
            return true;
            
        }
    }
}
