﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.IdentityModel.Tokens;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using System.Text;
using AspDotNetCoreWebApi_TokenBasedAuthetication.Filters;
using Microsoft.AspNetCore.Authorization;
using AspDotNetCoreWebApi_TokenBasedAuthetication.Controllers;

namespace AspDotNetCoreWebApi_TokenBasedAuthetication
{
    public class Startup
    {
        public Startup(IConfiguration configuration)
        {
            Configuration = configuration;
        }

        public IConfiguration Configuration { get; }

        // This method gets called by the runtime. Use this method to add services to the container.
        public void ConfigureServices(IServiceCollection services)
        {
            services.Configure<TokenManagement>(Configuration.GetSection("tokenManagement"));
            var token = Configuration.GetSection("tokenManagement").Get<TokenManagement>();
            var secret = Encoding.ASCII.GetBytes(token.Secret);

            services.AddAuthentication(JwtBearerDefaults.AuthenticationScheme)
                .AddJwtBearer(options =>
               {
                   //options.SaveToken = true;
                   //options.RequireHttpsMetadata = false;
                   options.TokenValidationParameters = new TokenValidationParameters()
                   {
                       ValidateIssuer = true,
                       ValidateAudience = true,
                       ValidateLifetime = true,
                       ValidateIssuerSigningKey = true,

                       ValidIssuer = token.Issuer, //Configuration["Jwt:Issuer"],
                       ValidAudience =token.Audience, //Configuration["Jwt:Issuer"],
                       IssuerSigningKey = new SymmetricSecurityKey(secret), // new SymmetricSecurityKey(Encoding.UTF8.GetBytes(Configuration["Jwt:Key"])),
                       RoleClaimType = "Role"
                   };

               });

            services.AddAuthorization(opt => {
                opt.AddPolicy("hasReportAccess", policy => policy.RequireClaim("access", "report").RequireRole("user"));
                
                opt.AddPolicy("officeHour", policy => policy.AddRequirements(new officeHourRequirment(8,23)).RequireRole("user"));
            });

            services.AddSingleton<IAuthorizationHandler, AuthorRequirementHandler>();
            services.AddSingleton<IAuthorizationHandler, officeHourRequirmentHandler>();
            services.AddScoped<IAuthenticateService, TokenAuthenticationService>();
            services.AddScoped<IUserManagementService, UserManagementService>();
            services.AddMvc().SetCompatibilityVersion(CompatibilityVersion.Version_2_2);

          
        }

        // This method gets called by the runtime. Use this method to configure the HTTP request pipeline.
        public void Configure(IApplicationBuilder app, IHostingEnvironment env)
        {
            if (env.IsDevelopment())
            {
                app.UseDeveloperExceptionPage();
            }

            app.ConfigureExceptionHandler();
            app.UseAuthentication();
            app.UseMvc();
        }
    }
}
