﻿using System;
using System.Collections.Generic;
using System.IdentityModel.Tokens.Jwt;
using System.Linq;
using System.Security.Claims;
using System.Text;
using System.Threading.Tasks;
using AspDotNetCoreWebApi_TokenBasedAuthetication.Model;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using Microsoft.IdentityModel.Tokens;

namespace AspDotNetCoreWebApi_TokenBasedAuthetication.Controllers
{
    [Authorize]
    [Route("api/[controller]/[action]")]
    [ApiController]
    public class AccountController : ControllerBase
    {
        private IAuthorizationService _authorizationService;
        private IConfiguration _config;
        private readonly IAuthenticateService _authService;
        private readonly IUserManagementService _userManagementService;

        public AccountController(IConfiguration config, IAuthenticateService authService, IUserManagementService managementservice, IAuthorizationService authorizationService)
        {
            _config = config;
            _authService = authService;
            _userManagementService = managementservice;
            _authorizationService = authorizationService;
        }

        [AllowAnonymous]
        [HttpPost]
        public IActionResult Login([FromBody]UserModel login)
        {
            IActionResult response = Unauthorized();
            if (!_userManagementService.IsValidUser(login.Username, login.EmailAddress))
                return response;

            string tokenstring;

            if (_authService.IsAuthenticated(login, out tokenstring))
            {
                response = Ok(new { token = tokenstring });
            }
           //// var user = AuthenticateUser(login);

           // if (user != null)
           // {
           //     var tokenString = GenerateJSONWebToken(user);
           //     response = Ok(new { token = tokenString });
           // }

            return response;
        }


        //Role based authorization
        [HttpGet("profile")]
        [Authorize(Roles = "admin")]
        public string GetProfile()
        {
            return $"{HttpContext.User.Identity.Name} is authorized!";
        }

        //Claim Based authorization
        [HttpGet("report")]
        [Authorize(Policy = "hasReportAccess")]
        public string GetReport()
        {
            return $"{HttpContext.User.Identity.Name} is authorized!";
        }

        //Policy based authorization
        [HttpGet("financereport")]
        [Authorize(Policy = "officeHour")]
        public string GetFinanceReport()
        {
            return $"{HttpContext.User.Identity.Name} is authorized!";
        }

        //Resource based authorization
        //[HttpGet("report/{id}")]
        [HttpGet, Authorize(policy: "officeHour")]
        public async Task<IActionResult> PutReport(string id)
        {

            string a = "fff";
            string b = $"moiohfogjf{a}";


            var report = new Report { Author = "alice", Content = "" }; // Here we would get the resource from somewhere
            var result = await _authorizationService.AuthorizeAsync(HttpContext.User, report, new AuthorRequirement());
            if (result.Succeeded)
            {
                return Ok();
            }
            else
            {
                return Unauthorized();
            }
        }

        // GET api/Account/Get
        [HttpGet,Authorize(policy: "officeHour"),Authorize(policy: "hasReportAccess")]
        public ActionResult<IEnumerable<string>> Get()
        {
            return new string[] { "value1", "value2" };
        }

        //GET api/Account/GetUserRole
        [HttpGet(Name = "GetUserRole"), Authorize(Roles ="Admin")]
        public string GetUserRole()
        {
            string result = string.Empty;

            var user = HttpContext.User;

            var claims = user.Claims;


            if (user.HasClaim(x => x.Type == "Role"))
            {
                result = user.Claims.FirstOrDefault(x => x.Type == "Role").Value;
            }

            return result;
        }

        private string GenerateJSONWebToken(UserModel user)
        {
            var securityKey = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(_config["Jwt:Key"]));
            var credentials = new SigningCredentials(securityKey, SecurityAlgorithms.HmacSha256);

            List<Claim> claims = new List<Claim>();
            claims.Add(new Claim(JwtRegisteredClaimNames.GivenName, user.Username));
            claims.Add(new Claim("Role", user.Role));
            claims.Add(new Claim(JwtRegisteredClaimNames.Email, user.EmailAddress));


            var token = new JwtSecurityToken(_config["Jwt:Issuer"], _config["Jwt:Issuer"], claims, expires: DateTime.Now.AddMinutes(5), signingCredentials: credentials);
                    

            return new JwtSecurityTokenHandler().WriteToken(token);
        }

        private UserModel AuthenticateUser(UserModel login)
        {
            //Autheticate the user from database
            UserModel model = null;
            if (login.Username.ToLower() == "admin" && login.EmailAddress.ToLower() == "admin@test.com")
            {
                model = new UserModel { Username = "Admin", EmailAddress = "admin@test.com",Role ="Admin" };
            }
            if (login.Username.ToLower() == "user" && login.EmailAddress.ToLower() == "user@test.com")
            {
                model = new UserModel { Username = "User", EmailAddress = "user@test.com", Role = "User" };
            }

            return model;
        }


    }

}