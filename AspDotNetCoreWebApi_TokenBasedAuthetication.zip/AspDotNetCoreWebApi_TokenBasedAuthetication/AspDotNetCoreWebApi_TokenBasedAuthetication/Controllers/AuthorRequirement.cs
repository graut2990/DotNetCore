﻿using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Authorization;
using System.Threading.Tasks;

namespace AspDotNetCoreWebApi_TokenBasedAuthetication.Controllers
{
    public class AuthorRequirement : IAuthorizationRequirement { }

    public class AuthorRequirementHandler : AuthorizationHandler<AuthorRequirement, Report>
    {
        protected override Task HandleRequirementAsync(
            AuthorizationHandlerContext context,
            AuthorRequirement requirement,
            Report resource)
        {
            if (context.User.Identity.Name == resource.Author)
            {
                context.Succeed(requirement);
            }

            return Task.CompletedTask;
        }
    }
     
}