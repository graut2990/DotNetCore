﻿namespace AspDotNetCoreWebApi_TokenBasedAuthetication.Controllers
{
    public class Report
    {
        public string Author { get; set; }
        public string Content { get; set; }
    }
}