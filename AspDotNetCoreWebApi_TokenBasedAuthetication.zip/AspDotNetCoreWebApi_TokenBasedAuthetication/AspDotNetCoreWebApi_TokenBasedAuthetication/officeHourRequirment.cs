﻿using Microsoft.AspNetCore.Authorization;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace AspDotNetCoreWebApi_TokenBasedAuthetication
{
    public class officeHourRequirment : IAuthorizationRequirement
    {
        public  officeHourRequirment(int start, int end)
        {
            Start = start;
            End = end;
        }
        public int Start { get; set; }
        public int End { get; set; }
    }

    public class officeHourRequirmentHandler : AuthorizationHandler<officeHourRequirment>
    {
        protected override Task HandleRequirementAsync(AuthorizationHandlerContext context, officeHourRequirment requirement)
        {
            var Now = DateTime.Now;
            if (Now.Hour > requirement.Start && Now.Hour < requirement.End)
            {
                context.Succeed(requirement);
            }
            return Task.CompletedTask;
        }
    }
}
