﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace AspDotNetCoreWebApi_TokenBasedAuthetication
{
    public interface IUserManagementService
    {
        bool IsValidUser(string username, string password);
    }

    public class UserManagementService : IUserManagementService
    {
        public bool IsValidUser(string userName, string emailAddress)
        {
            if (userName.ToLower() == "admin" && emailAddress.ToLower() == "admin@test.com")
            {
                return true;
                //model = new UserModel { Username = "Admin", EmailAddress = "admin@test.com", Role = "Admin" };
            }
            if (userName.ToLower() == "user" && emailAddress.ToLower() == "user@test.com")
            {
                return true;
                //model = new UserModel { Username = "User", EmailAddress = "user@test.com", Role = "User" };
            }
            //return model;
            return false;
        }
    }
}
