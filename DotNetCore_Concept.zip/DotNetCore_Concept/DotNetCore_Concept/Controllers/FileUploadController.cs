﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading.Tasks;
using DotNetCore_Concept.Models;
using DotNetCore_Concept.ViewModels;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace DotNetCore_Concept.Controllers
{
    public class FileUploadController : Controller
    {
   
        private readonly IHostingEnvironment _environment;

        public FileUploadController( IHostingEnvironment environment)
        {            
            _environment = environment;
            
        }

        [HttpPost,Consumes("multipart/form-data")]
        //[ValidateAntiForgeryToken]
        public async Task<IActionResult> Create(IFormFile files)
        {          

            if (files == null || files.Length == 0)
                return Content("file not selected");

            var filePath = Path.Combine(_environment.ContentRootPath, @"Uploads", files.FileName);

                using (var stream = new FileStream(filePath, FileMode.Create))
                {
                        await files.CopyToAsync(stream);
                }

               
                return RedirectToAction(nameof(Index));
           
        }

        public string Index()
        {
            return "File Uploaded successfully to check file click below link http://localhost:3992/Uploads";  
        }

    }
}