﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace DotNetCore_Concept.Controllers
{
    public class CatchAllController : Controller
    {
        [HttpGet("{*url}", Order = int.MaxValue)]
        public string CatchAll()
        {
            this.Response.StatusCode = StatusCodes.Status404NotFound;
            return $"Catchall{this.Response.StatusCode}";
        }
    }
}