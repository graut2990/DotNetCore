﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;

namespace DotNetCore_Concept.Controllers
{
    //[Route("MobileHome")]
    public class MobileHomeController : Controller
    {
        //[Route("New/Index1/{id:int?}")]
        public string Index()
        { 
            return "response from mobile";
        }
    }
}