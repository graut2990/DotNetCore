﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using DotNetCore_Concept.Models;
using System.Web;
using Microsoft.Extensions.Configuration;

namespace DotNetCore_Concept.Controllers
{
    //[Route("Home")]
    public class HomeController : Controller
    {
        // [Route("New/Index1/{id:int?}")]
        

        public HomeController(IConfiguration config)
        {
            var dtd = config.GetSection("test").GetValue<string>("key");
        }
        public string Index()
        {            
            if (this.HttpContext.Items["timestamp"] == null)
                this.HttpContext.Items["timestamp"] = "Gaurav";
            return HttpUtility.HtmlEncode("Please confirm your account by <a href='{HtmlEncoder.Default.Encode(link)}'>clicking here</a>"); 

        }
        [HttpGet,HttpHead]
        public IActionResult Privacy()
        {
            HttpContext.Response.Headers.Add("Allow", "GET,OPTIONS");
            var obj = new { id = "1ba6271109d445c8972542985b2d3e96", createdDate = "2017-09-24T21:08:50.9990689Z", lastUpdatedDate = "2017-09-24T21:08:50.9990693Z", name = "Leia Organa", gender = "Female", height = "150" };
            return new ObjectResult(obj);
    }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }

        [HttpHead,HttpGet,HttpPatch,HttpPost,HttpOptions]        
        [Route("Books", Name = "Options")]
        public IActionResult Options()
        {
            //HttpContext.Response.Headers.Add("Allow", "GET,OPTIONS");
                //.Current.Response.AppendHeader("Allow", "GET,OPTIONS");
            
            return Ok();
        }
    }
}
