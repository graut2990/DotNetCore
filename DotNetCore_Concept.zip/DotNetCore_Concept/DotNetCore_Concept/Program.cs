﻿using Microsoft.AspNetCore;
using Microsoft.AspNetCore.Hosting;
using System.IO;

namespace DotNetCore_Concept
{
    public class Program
    {
        public static void Main(string[] args)
        {
            //var host = new WebHostBuilder()
            //            .UseKestrel()
            //            .UseEnvironment("Development")
            //            .UseContentRoot(Directory.GetCurrentDirectory())
            //            .UseIISIntegration()
            //            .UseStartup<Startup>()
            //            .Build();
            //host.Run();

            CreateWebHostBuilder(args).Build().Run();
        }

        public static IWebHostBuilder CreateWebHostBuilder(string[] args) =>

            WebHost.CreateDefaultBuilder(args)
                .UseStartup<Startup>();
    }
}
