﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Rewrite;
using Microsoft.Net.Http.Headers;

namespace DotNetCore_Concept.Models
{
    public class RedirectToMobile
    {
    }

    public class MobileRedirectRule : IRule
    {
        private readonly string[] matchPaths;
        private readonly PathString newPath;

        
        public MobileRedirectRule()
        {
            //if (matchPaths.Count() == 0)
            //    throw new ArgumentException("matchPaths empty");

            //if (matchPaths.Where(s => !s.StartsWith("/")).Count() > 0)
            //    throw new ArgumentException("matchWith values must start with /");

            //if (string.IsNullOrEmpty(newPath))
            //    throw new ArgumentException("newPath missing");

            //if (!newPath.StartsWithSegments("/"))
            //    throw new ArgumentException("newPath must start with /");
           
            this.matchPaths = matchPaths;
            this.newPath = new PathString(newPath);
        }
        public void ApplyRule(RewriteContext context)
        {
            var headers = context.HttpContext.Request.Headers;
            var path = context.HttpContext.Request.Path.Value.Split('/');

            var request = context.HttpContext.Request;
            if (request.Path.Value.Contains("Mobile"))
            {
                return;
            }
          
            //if ()
            //{
                if (headers.ContainsKey("User-Agent") && headers["User-Agent"].ToString().Contains("Mozilla"))
                {
                    var action = string.Empty;
                    var controller = string.Empty;
                    if (path.Length > 1)
                    {
                        controller = path[1];
                        if (path.Length > 2)
                            action = path[2];

                        var newLocation = $"Mobile{controller}/{action}";

                        var response = context.HttpContext.Response;
                        response.StatusCode = StatusCodes.Status301MovedPermanently;
                        context.Result = RuleResult.EndResponse;
                        response.Headers[HeaderNames.Location] = newLocation;
                    
                    }
                
                }
            //}

        
        }
    }
}
