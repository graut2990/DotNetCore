﻿using System.IO;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.FileProviders;

namespace DotNetCore_Concept
{
    public class Startup
    {
        public Startup(IConfiguration configuration)
        {
            Configuration = configuration;           
        }

        public IConfiguration Configuration { get; }

        // This method gets called by the runtime. Use this method to add services to the container.
        public void ConfigureServices(IServiceCollection services)
        {
            services.Configure<CookiePolicyOptions>(options =>
            {
                // This lambda determines whether user consent for non-essential cookies is needed for a given request.
                options.CheckConsentNeeded = context => true;
                options.MinimumSameSitePolicy = SameSiteMode.None;
            });

            
            services.AddMvc(options =>
           options.EnableEndpointRouting = false).SetCompatibilityVersion(CompatibilityVersion.Version_2_2);  //options => { options.EnableEndpointRouting = false; }
        }
        
        // This method gets called by the runtime. Use this method to configure the HTTP request pipeline.
        public void Configure(IApplicationBuilder app, IHostingEnvironment env)
        {
            var dd = env.EnvironmentName;
            var builder = new ConfigurationBuilder().SetBasePath(env.ContentRootPath)
               .AddJsonFile($"appsettings.{env.EnvironmentName}.json", optional: true).AddEnvironmentVariables();

           
            if (env.IsDevelopment())
            {
                app.UseDeveloperExceptionPage();
            }
            else
            {
                app.UseExceptionHandler("/Home/Error");
            }
            

             app.UseStaticFiles();  //default serves the wwwroot content 

            app.UseStaticFiles(new StaticFileOptions
            {
                //serving the root content
                FileProvider = new PhysicalFileProvider(
                Path.Combine(Directory.GetCurrentDirectory()))
                ,RequestPath = new PathString("/rootcontent")

                //FileProvider = new PhysicalFileProvider(Path.Combine(env.ContentRootPath, "Uploads")),
                //RequestPath = new PathString("/Uploads")
            });

            //FileServerOptions obj = new FileServerOptions();
            //obj.EnableDirectoryBrowsing = true;
            //obj.DirectoryBrowserOptions.FileProvider = new PhysicalFileProvider(
            //    Path.Combine(Directory.GetCurrentDirectory(), @"Uploads"));
            //obj.RequestPath = "/Uploads";

            //app.UseFileServer(obj);

            //app.UseStaticFiles(new StaticFileOptions()
            //{
            //    FileProvider = new PhysicalFileProvider(
            //    Path.Combine(Directory.GetCurrentDirectory(), @"Uploads")),
            //    RequestPath = new PathString("/Uploads")
            //});

            //app.UseDirectoryBrowser(new DirectoryBrowserOptions()
            //{
            //    FileProvider = new PhysicalFileProvider(
            //        Path.Combine(Directory.GetCurrentDirectory(), @"Uploads")),
            //    RequestPath = new PathString("/Uploads")
            //});


            app.UseMvc(routes =>
            {

                //routes.MapRoute(
                //  name: "MyArea",
                //  template: "{area:exists}/{controller=Home}/{action=Index}/{id?}");

                routes.MapAreaRoute(
                    name: "MyAreaProducts",
                    areaName: "Products",
                    template: "Product/{controller=Home}/{action=Index}/{id?}");


                routes.MapRoute(
                   name: "default",
                   template: "{controller=Home}/{action=Index}/{id?}");

                //routes.MapRoute(
                //    name: "CatchAll",
                //    template: "{*url}",
                //    defaults: new { controller = "CatchAll", action = "CatchAll" });

            });
            //app.Run()

            //var rewrite = new RewriteOptions()
            //    .Add(new MobileRedirectRule());

            //app.UseRewriter(rewrite);

            //app.UseStaticFiles();
            //app.UseCookiePolicy();


            //app.UseMvc(routes =>
            //{
            //routes.Routes.Add(new CustomRouter(routes.DefaultHandler));

            //routes.MapRoute(
            //    name: "default",
            //    template: "{controller=Home}/{action=Index}/{id?}");
            //routes.MapRoute(
            //    name: "Api",
            //    template: "{controller}/{action}/{id?}");
            //  });
        }

        
    }
}

