﻿using Microsoft.AspNetCore.Mvc;

namespace DotNetCore_Concept.Areas.Products
{
//    [Route("api/[controller]")]
//    [ApiController]
//    public class HomeController : ControllerBase
//    {
//    }
    public class HomeController : Controller
    {
         
        [Area("Products")]
        public string Index()
        {
            if(this.HttpContext.Items["timestamp"] == null)
                this.HttpContext.Items["timestamp"] = "Gaurav";

            return "Response from Product/home/index";
        }
}

}