﻿namespace AspDotNetCoreWebApi_FiltersDemo.Filters
{
    public interface ILoggerManager
    {
    }
}