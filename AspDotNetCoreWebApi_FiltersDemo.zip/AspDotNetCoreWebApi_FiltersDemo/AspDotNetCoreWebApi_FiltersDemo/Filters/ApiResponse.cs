﻿namespace AspDotNetCoreWebApi_FiltersDemo.Filters
{
    internal class ApiResponse
    {
        public string Message { get; set; }
        public object Data { get; set; }
    }
}