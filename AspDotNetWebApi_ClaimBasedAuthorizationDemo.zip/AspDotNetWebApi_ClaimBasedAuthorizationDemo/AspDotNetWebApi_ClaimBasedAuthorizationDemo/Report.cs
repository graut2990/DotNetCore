﻿namespace AspDotNetWebApi_ClaimBasedAuthorizationDemo
{
    public class Report
    {
        public string Author { get; set; }
        public string Content { get; set; }
    }
}